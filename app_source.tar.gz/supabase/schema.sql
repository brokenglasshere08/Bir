-- Supabase Schema for Aura Medical & Dental Clinic (Dr. Ananya Rao)
-- Run this in your Supabase project SQL Editor: https://supabase.com/dashboard/project/eaasarhbhpymzffbkjtu/sql

-- 1. Appointments Table
CREATE TABLE IF NOT EXISTS public.appointments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    booking_reference VARCHAR(50) UNIQUE NOT NULL,
    patient_name VARCHAR(255) NOT NULL,
    patient_phone VARCHAR(50) NOT NULL,
    patient_email VARCHAR(255) NOT NULL,
    patient_notes TEXT,
    service_ids TEXT[] NOT NULL DEFAULT '{}',
    service_names TEXT[] NOT NULL DEFAULT '{}',
    date DATE NOT NULL,
    time VARCHAR(50) NOT NULL,
    total_amount NUMERIC NOT NULL,
    payment_status VARCHAR(50) NOT NULL DEFAULT 'PAID',
    payment_method VARCHAR(50) DEFAULT 'upi',
    transaction_id VARCHAR(100),
    status VARCHAR(50) NOT NULL DEFAULT 'CONFIRMED',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2. Payments Table
CREATE TABLE IF NOT EXISTS public.payments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id VARCHAR(100) NOT NULL,
    amount NUMERIC NOT NULL,
    currency VARCHAR(10) NOT NULL DEFAULT 'INR',
    method VARCHAR(50) NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'SUCCESS',
    transaction_ref VARCHAR(100) NOT NULL,
    upi_app VARCHAR(50),
    upi_id VARCHAR(100),
    card_last4 VARCHAR(4),
    card_brand VARCHAR(50),
    bank_name VARCHAR(100),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 3. Services Table
CREATE TABLE IF NOT EXISTS public.services (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    category VARCHAR(100) NOT NULL,
    numeric_price NUMERIC NOT NULL,
    duration_minutes INT NOT NULL,
    price_text VARCHAR(100) NOT NULL,
    breakdown TEXT,
    description TEXT,
    image_url TEXT,
    includes TEXT[] DEFAULT '{}',
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Enable Row Level Security (RLS)
ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;

-- Allow anonymous read and insert for the booking application
CREATE POLICY "Allow public insert on appointments" 
    ON public.appointments FOR INSERT WITH CHECK (true);

CREATE POLICY "Allow public select on appointments" 
    ON public.appointments FOR SELECT USING (true);

CREATE POLICY "Allow public insert on payments" 
    ON public.payments FOR INSERT WITH CHECK (true);

CREATE POLICY "Allow public select on payments" 
    ON public.payments FOR SELECT USING (true);

CREATE POLICY "Allow public select on services" 
    ON public.services FOR SELECT USING (true);

-- Seed Services
INSERT INTO public.services (id, name, category, numeric_price, duration_minutes, price_text, breakdown, description, image_url, includes)
VALUES
('rc', 'Root Canal', 'Endodontics', 4500, 60, 'Starting from ₹4,500', 'Est. ₹4,500 - ₹6,500 (Incl. Specialist Consultation & RVG X-Ray; Crown extra)', 'Infection treatment and restorative care for compromised tooth roots using computerized apex locators and painless anesthesia.', '/src/assets/images/treatment_root_canal_1790167223532.jpg', ARRAY['Pre-op Digital RVG X-Ray', 'Computerized Apex Locator canal shaping', 'Biocompatible Gutta-percha obturation', 'Temporary restorative filling']),
('te', 'Tooth Extraction', 'Oral Surgery', 1500, 45, 'Starting from ₹1,500', 'Est. ₹1,500 - ₹3,500 (Includes Local Anesthesia, Sutures & Post-Op Medication Pack)', 'Gentle surgical and non-surgical extractions including impacted wisdom molars with atraumatic luxators.', '/src/assets/images/treatment_tooth_extraction_1790167258957.jpg', ARRAY['Specialist oral examination', 'Atraumatic luxation technique', 'Sterile resorbable collagen dressing', 'Comprehensive post-op prescription']),
('dc', 'Deep Cleaning', 'Periodontics', 2000, 45, 'Starting from ₹2,000', 'Est. ₹2,000 - ₹3,200 (Full-mouth Ultrasonic Scaling + Prophy-Jet Stain Polish)', 'Full-mouth subgingival scaling, calculus removal, and micro-polishing to eradicate plaque and reverse gingivitis.', '/src/assets/images/treatment_deep_cleaning_1790167236130.jpg', ARRAY['Subgingival piezoelectric ultrasonic scaling', 'Prophy-Jet bicarbonate air polishing', 'Gingival pocket measurement & irrigation', 'Fluoride remineralization polish']),
('ob', 'Orthodontic Braces', 'Orthodontics', 25000, 60, 'Starting from ₹25,000', 'Est. ₹25,000 - ₹60,000 (Metal, Ceramic, Self-Ligating, or Clear Aligners packages)', 'Comprehensive alignment correction for malocclusion, overcrowding, and bite alignment using modern orthodontic fixtures.', '/src/assets/images/treatment_orthodontic_braces_1790167247551.jpg', ARRAY['Orthodontic diagnostic photography & cast analysis', 'High-grade ceramic / stainless brackets fixture', 'Initial nickel-titanium archwire placement', 'Custom orthodontic hygiene starter kit']),
('tc', 'Teeth Whitening', 'Cosmetic Dentistry', 7500, 60, 'Starting from ₹7,500', 'Est. ₹7,500 - ₹12,000 (In-office LED Laser Power Bleaching with Home Maintenance Kit)', 'Advanced chairside LED blue light laser bleaching to lighten enamel shades safely by 4 to 8 tones.', '/src/assets/images/treatment_teeth_whitening_1790167270459.jpg', ARRAY['Enamel shade baseline matching', 'Gingival barrier isolation application', 'Medical-grade hydrogen peroxide gel', 'Desensitizing calcium phosphate rinse']),
('cs', 'Cardiovascular Screening', 'Cardiology', 3500, 45, 'Starting from ₹3,500', 'Est. ₹3,500 - ₹5,500 (Includes 12-Lead ECG, Lipid Profile Analysis & Consultation)', 'Comprehensive heart checkup covering arterial elasticity, blood pressure monitoring, and lipid cardiac profile.', '/src/assets/images/treatment_cardiac_consultation_1790167282038.jpg', ARRAY['12-Lead Digital Electrocardiogram (ECG)', 'Cardiac risk score evaluation', 'Vascular blood pressure examination', 'Preventive lifestyle and dietary counseling'])
ON CONFLICT (id) DO NOTHING;
