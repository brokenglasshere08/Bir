import React from 'react';
import { CheckCircle2, Calendar, Clock, MapPin, Download, ExternalLink, ShieldCheck, Printer } from 'lucide-react';
import { Appointment } from '../server/types.js';

interface ConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  appointment: Appointment | null;
  onViewAllBookings: () => void;
}

export const ConfirmationModal: React.FC<ConfirmationModalProps> = ({
  isOpen,
  onClose,
  appointment,
  onViewAllBookings
}) => {
  if (!isOpen || !appointment) return null;

  // Generate Google Calendar Link
  const getGoogleCalendarUrl = () => {
    const title = encodeURIComponent(`Dr. Ananya Rao - ${appointment.serviceNames.join(', ')}`);
    const details = encodeURIComponent(
      `Appointment Ref: ${appointment.appointmentNumber}\nClinic: Aura Medical & Dental Wellness Centre\nPatient: ${appointment.patientName}\nAmount Paid: ₹${appointment.totalAmount}\nReceipt: ${appointment.paymentDetails.receiptNumber}`
    );
    const location = encodeURIComponent('Suite 402, 100ft Road, Indiranagar, Bangalore');

    // Parse date and time (e.g., "2026-09-24", "04:15 PM")
    const dateParts = appointment.date.split('-');
    const [timeStr, period] = appointment.time.split(' ');
    const [hourStr, minStr] = timeStr.split(':');
    let hour = parseInt(hourStr, 10);
    if (period === 'PM' && hour < 12) hour += 12;
    if (period === 'AM' && hour === 12) hour = 0;

    const startDate = new Date(
      parseInt(dateParts[0], 10),
      parseInt(dateParts[1], 10) - 1,
      parseInt(dateParts[2], 10),
      hour,
      parseInt(minStr, 10)
    );
    const endDate = new Date(startDate.getTime() + 60 * 60 * 1000);

    const formatCalTime = (d: Date) => d.toISOString().replace(/-|:|\.\d+/g, '');
    const dates = `${formatCalTime(startDate)}/${formatCalTime(endDate)}`;

    return `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${title}&dates=${dates}&details=${details}&location=${location}`;
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Appointment Confirmation"
      className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4"
    >
      <div className="bg-white rounded-3xl p-6 max-w-sm w-full text-center space-y-4 shadow-2xl border border-slate-200 animate-scaleUp">
        <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center text-3xl mx-auto ring-8 ring-emerald-50">
          <CheckCircle2 className="w-8 h-8" />
        </div>

        <div>
          <span className="text-[11px] font-bold text-emerald-600 uppercase tracking-wider bg-emerald-50 px-2 py-0.5 rounded-md">
            Payment Verified & Slot Confirmed
          </span>
          <h2 className="text-xl font-black text-slate-900 mt-1">Appointment Confirmed!</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Ref: <span className="font-mono font-bold text-slate-800">{appointment.appointmentNumber}</span>
          </p>
        </div>

        {/* Appointment Details Box */}
        <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 text-left text-xs space-y-2.5 font-medium">
          <div className="flex justify-between items-start">
            <span className="text-slate-400">Doctor:</span>
            <span className="font-bold text-slate-900 text-right">Dr. Ananya Rao</span>
          </div>

          <div className="flex justify-between items-start">
            <span className="text-slate-400">Patient:</span>
            <span className="font-bold text-slate-900 text-right">{appointment.patientName}</span>
          </div>

          <div className="flex justify-between items-start">
            <span className="text-slate-400">Treatments:</span>
            <span className="font-bold text-slate-900 text-right max-w-[180px] truncate">
              {appointment.serviceNames.join(', ')}
            </span>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-slate-400">Date:</span>
            <span className="font-bold text-slate-900 flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-blue-600" />
              {appointment.date}
            </span>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-slate-400">Time:</span>
            <span className="font-bold text-slate-900 flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-blue-600" />
              {appointment.time}
            </span>
          </div>

          <div className="flex justify-between items-center pt-2 border-t border-slate-200">
            <span className="text-slate-500 font-bold">Total Paid:</span>
            <span className="font-extrabold text-blue-600 text-sm">
              ₹{appointment.totalAmount.toLocaleString('en-IN')}
            </span>
          </div>

          <div className="flex justify-between items-center text-[10px] text-slate-400">
            <span>Receipt #{appointment.paymentDetails.receiptNumber}</span>
            <span className="uppercase font-bold text-slate-600">
              {appointment.paymentMethod}
              {appointment.paymentDetails.upiApp ? ` (${appointment.paymentDetails.upiApp})` : ''}
            </span>
          </div>
        </div>

        {/* Quick action buttons */}
        <div className="space-y-2 pt-1">
          <a
            href={getGoogleCalendarUrl()}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full py-2.5 bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 transition border border-blue-200"
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>Add to Google Calendar</span>
            <ExternalLink className="w-3 h-3 ml-0.5" />
          </a>

          <p className="text-[10px] text-slate-500 mt-2 px-2 leading-relaxed">
            Pay a refundable amount to confirm your appointment slot. The refundable amount will be refunded only if canceled at least 30 minutes before your appointment.
          </p>

          <button
            type="button"
            onClick={onViewAllBookings}
            className="w-full py-2.5 bg-slate-900 hover:bg-black text-white font-bold rounded-xl text-xs transition mt-2"
          >
            <span>My Bookings</span>
          </button>
        </div>
      </div>
    </div>
  );
};
