import React, { useState } from 'react';
import {
  CreditCard,
  Smartphone,
  ShieldCheck,
  Lock,
  Check,
  QrCode,
  Tag,
  Building,
  AlertCircle,
  Clock,
  User,
  Phone,
  Mail,
  FileText
} from 'lucide-react';
import { TreatmentService } from '../server/types.js';

// Payment View Component


interface PaymentViewProps {
  selectedServices: TreatmentService[];
  selectedDate: Date;
  selectedTime: string;
  onPaymentSuccess: (bookingResult: any) => void;
  showToast: (msg: string) => void;
}

export const PaymentView: React.FC<PaymentViewProps> = ({
  selectedServices,
  selectedDate,
  selectedTime,
  onPaymentSuccess,
  showToast
}) => {
  // Patient details state
  const [patientName, setPatientName] = useState('');
  const [patientPhone, setPatientPhone] = useState('');
  const [patientEmail, setPatientEmail] = useState('');
  const [patientNotes, setPatientNotes] = useState('');

  // Payment method selection
  const [paymentMethod, setPaymentMethod] = useState<'upi' | 'card' | 'netbanking'>('upi');
  const [selectedUpiApp, setSelectedUpiApp] = useState<'gpay' | 'phonepe' | 'bhim' | 'paytm' | 'custom'>('gpay');
  const [customUpiId, setCustomUpiId] = useState('');
  const [showQrCode, setShowQrCode] = useState(false);

  // Card details state
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');
  const [cardHolder, setCardHolder] = useState('');

  // Netbanking state
  const [selectedBank, setSelectedBank] = useState('HDFC Bank');

  // Coupon state
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<string | null>(null);
  const [discountAmount, setDiscountAmount] = useState(0);

  // Processing simulation state
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingStage, setProcessingStage] = useState<'handshake' | 'gateway' | 'confirming'>('handshake');
  const [showOtpModal, setShowOtpModal] = useState(false);
  const [otpCode, setOtpCode] = useState('4928');
  const [showUpiConfirmModal, setShowUpiConfirmModal] = useState(false);
  const [pendingOrderData, setPendingOrderData] = useState<any>(null);

  // Price calculations
  const baseAmount = 399; // ₹399 refundable deposit
  const totalPayable = Math.max(0, baseAmount - discountAmount);

  // Apply discount coupon
  const handleApplyCoupon = () => {
    const code = couponCode.trim().toUpperCase();
    if (!code) return;

    // Cap discount at ₹50
    const discount = Math.min(50, Math.round(baseAmount * 0.1));
    setDiscountAmount(discount);
    setAppliedCoupon(`${code} (Discount applied)`);
    showToast('Coupon applied! Discount added.');
  };

  const handleRemoveCoupon = () => {
    setCouponCode('');
    setAppliedCoupon(null);
    setDiscountAmount(0);
  };

  // Format Card Number (XXXX XXXX XXXX XXXX)
  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value.replace(/\D/g, '').slice(0, 16);
    const formatted = val.match(/.{1,4}/g)?.join(' ') || val;
    setCardNumber(formatted);
  };

  // Format Expiry (MM/YY)
  const handleExpiryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let val = e.target.value.replace(/\D/g, '').slice(0, 4);
    if (val.length >= 2) {
      val = `${val.slice(0, 2)}/${val.slice(2)}`;
    }
    setCardExpiry(val);
  };

  // Trigger payment flow
  const handleInitiatePayment = async () => {
    // Validate patient form
    if (!patientName.trim()) {
      showToast('Please enter patient full name.');
      return;
    }
    if (!patientPhone.trim() || patientPhone.replace(/\D/g, '').length < 10) {
      showToast('Please enter a valid 10-digit mobile number.');
      return;
    }
    // Email is now optional, removed validation
    
    // Validate payment fields
    if (paymentMethod === 'card') {
      const cleanCard = cardNumber.replace(/\s/g, '');
      if (cleanCard.length < 15) {
        showToast('Please enter a valid 16-digit card number.');
        return;
      }
      if (cardExpiry.length < 5) {
        showToast('Please enter valid expiration date (MM/YY).');
        return;
      }
      if (cardCvv.length < 3) {
        showToast('Please enter 3-digit CVV.');
        return;
      }
      if (!cardHolder.trim()) {
        showToast('Please enter name as printed on card.');
        return;
      }
      // Trigger card 3DS OTP modal for authentic security experience!
      setShowOtpModal(true);
      return;
    }
    // ... (keep UPI and netbanking logic)

    if (paymentMethod === 'upi') {
      if (selectedUpiApp === 'custom' && !customUpiId.includes('@')) {
        showToast('Please enter a valid UPI ID (e.g., yourname@okhdfcbank).');
        return;
      }
      
      // Initialize order, open UPI intent, and directly verify payment against backend
      setIsProcessing(true);
      setProcessingStage('gateway');
      try {
        const orderRes = await fetch('/api/payments/create-order', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            serviceIds: selectedServices.map((s) => s.id),
            couponCode: appliedCoupon ? couponCode : undefined
          })
        });

        if (!orderRes.ok) {
          const err = await orderRes.json();
          throw new Error(err.error || 'Failed to initialize payment gateway order');
        }

        const orderData = await orderRes.json();

        const merchantUpiId = '8123387401@axl';
        const payeeName = 'Modern Dental Care';
        const amount = orderData.totalAmount;
        const transactionRef = `TXN${Date.now()}`;
        
        let upiIntentUrl = `upi://pay?pa=${merchantUpiId}&pn=${encodeURIComponent(payeeName)}&am=${amount}&cu=INR&tn=${encodeURIComponent(`Appointment Payment - ${transactionRef}`)}`;
        
        if (selectedUpiApp === 'phonepe') {
          upiIntentUrl = `phonepe://pay?pa=${merchantUpiId}&pn=${encodeURIComponent(payeeName)}&am=${amount}&cu=INR&tn=${encodeURIComponent(`Appointment Payment - ${transactionRef}`)}`;
        } else if (selectedUpiApp === 'gpay') {
          upiIntentUrl = `tez://upi/pay?pa=${merchantUpiId}&pn=${encodeURIComponent(payeeName)}&am=${amount}&cu=INR&tn=${encodeURIComponent(`Appointment Payment - ${transactionRef}`)}`;
        } else if (selectedUpiApp === 'paytm') {
          upiIntentUrl = `paytmmp://pay?pa=${merchantUpiId}&pn=${encodeURIComponent(payeeName)}&am=${amount}&cu=INR&tn=${encodeURIComponent(`Appointment Payment - ${transactionRef}`)}`;
        }

        const anchor = document.createElement('a');
        anchor.href = upiIntentUrl;
        anchor.style.display = 'none';
        document.body.appendChild(anchor);
        try {
          anchor.click();
        } catch (e) {
          console.log('UPI intent launch fallback:', e);
        }
        document.body.removeChild(anchor);

        // Verify payment on backend
        setProcessingStage('confirming');
        await new Promise((r) => setTimeout(r, 1200));

        const upiAppName = selectedUpiApp === 'custom' ? customUpiId : selectedUpiApp.toUpperCase();
        const payRes = await fetch('/api/payments/process', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            orderId: orderData.orderId,
            amount: orderData.totalAmount,
            currency: 'INR',
            method: 'upi',
            upiApp: upiAppName
          })
        });

        if (!payRes.ok) {
          const err = await payRes.json();
          throw new Error(err.error || 'Payment verification failed');
        }

        const payData = await payRes.json();
        await new Promise((r) => setTimeout(r, 800));

        const formattedDate = `${selectedDate.getFullYear()}-${String(selectedDate.getMonth() + 1).padStart(
          2,
          '0'
        )}-${String(selectedDate.getDate()).padStart(2, '0')}`;

        const bookRes = await fetch('/api/appointments/book', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            patientName,
            patientPhone,
            patientEmail,
            patientNotes,
            serviceIds: selectedServices.map((s) => s.id),
            date: formattedDate,
            time: selectedTime,
            paymentTransactionId: payData.transaction.id,
            couponCode: appliedCoupon ? couponCode : undefined
          })
        });

        if (!bookRes.ok) {
          const err = await bookRes.json();
          throw new Error(err.error || 'Appointment booking failed');
        }

        const bookData = await bookRes.json();
        setIsProcessing(false);
        onPaymentSuccess(bookData.appointment);
        return;
      } catch (err: any) {
        setIsProcessing(false);
        showToast(err.message || 'Payment verification failed. Please try again.');
        return;
      }
    }

    if (paymentMethod === 'netbanking') {
      if (!selectedBank.trim()) {
        showToast('Please select your bank for Net Banking.');
        return;
      }
    }

    executePaymentTransaction();
  };

  // Execute payment and booking against the backend Express server
  const executePaymentTransaction = async () => {
    setIsProcessing(true);
    setProcessingStage('handshake');

    try {
      // Step 1: Create Order in backend
      const orderRes = await fetch('/api/payments/create-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          serviceIds: selectedServices.map((s) => s.id),
          couponCode: appliedCoupon ? couponCode : undefined
        })
      });

      if (!orderRes.ok) {
        const err = await orderRes.json();
        throw new Error(err.error || 'Failed to initialize payment gateway order');
      }

      const orderData = await orderRes.json();

      setProcessingStage('gateway');
      await new Promise((r) => setTimeout(r, 600));

      // If UPI intent is selected, trigger specific app scheme
      if (paymentMethod === 'upi') {
        const merchantUpiId = 'dentalclinic@okhdfcbank';
        const payeeName = 'Modern Dental Care';
        const amount = orderData.totalAmount;
        const transactionRef = `TXN${Date.now()}`;
        
        let upiIntentUrl = `upi://pay?pa=${merchantUpiId}&pn=${encodeURIComponent(payeeName)}&am=${amount}&cu=INR&tn=${encodeURIComponent(`Appointment Payment - ${transactionRef}`)}`;
        
        if (selectedUpiApp === 'phonepe') {
          upiIntentUrl = `phonepe://pay?pa=${merchantUpiId}&pn=${encodeURIComponent(payeeName)}&am=${amount}&cu=INR&tn=${encodeURIComponent(`Appointment Payment - ${transactionRef}`)}`;
        } else if (selectedUpiApp === 'gpay') {
          upiIntentUrl = `tez://upi/pay?pa=${merchantUpiId}&pn=${encodeURIComponent(payeeName)}&am=${amount}&cu=INR&tn=${encodeURIComponent(`Appointment Payment - ${transactionRef}`)}`;
        } else if (selectedUpiApp === 'paytm') {
          upiIntentUrl = `paytmmp://pay?pa=${merchantUpiId}&pn=${encodeURIComponent(payeeName)}&am=${amount}&cu=INR&tn=${encodeURIComponent(`Appointment Payment - ${transactionRef}`)}`;
        }

        console.log(`[UPI APP INTENT (${selectedUpiApp.toUpperCase()})]: ${upiIntentUrl}`);
        
        // Attempt opening app intent
        const anchor = document.createElement('a');
        anchor.href = upiIntentUrl;
        anchor.style.display = 'none';
        document.body.appendChild(anchor);
        try {
          anchor.click();
        } catch (e) {
          console.log('UPI intent launch fallback:', e);
        }
        document.body.removeChild(anchor);
      }

      await new Promise((r) => setTimeout(r, 1200));

      // Step 2: Process payment transaction
      const cardLast4 = paymentMethod === 'card' ? cardNumber.replace(/\s/g, '').slice(-4) : undefined;
      const upiAppName =
        paymentMethod === 'upi'
          ? selectedUpiApp === 'custom'
            ? customUpiId
            : selectedUpiApp.toUpperCase()
          : undefined;

      const payRes = await fetch('/api/payments/process', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          orderId: orderData.orderId,
          amount: orderData.totalAmount,
          currency: 'INR',
          method: paymentMethod,
          upiApp: upiAppName,
          cardLast4,
          cardBrand: paymentMethod === 'card' ? 'Card' : undefined,
          bankName: paymentMethod === 'netbanking' ? selectedBank : undefined
        })
      });

      if (!payRes.ok) {
        const err = await payRes.json();
        throw new Error(err.error || 'Payment declined by bank');
      }

      const payData = await payRes.json();

      setProcessingStage('confirming');
      await new Promise((r) => setTimeout(r, 700));

      // Step 3: Book confirmed appointment
      const formattedDate = `${selectedDate.getFullYear()}-${String(selectedDate.getMonth() + 1).padStart(
        2,
        '0'
      )}-${String(selectedDate.getDate()).padStart(2, '0')}`;

      const bookRes = await fetch('/api/appointments/book', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          patientName,
          patientPhone,
          patientEmail,
          patientNotes,
          serviceIds: selectedServices.map((s) => s.id),
          date: formattedDate,
          time: selectedTime,
          paymentTransactionId: payData.transaction.id,
          couponCode: appliedCoupon ? couponCode : undefined
        })
      });

      if (!bookRes.ok) {
        const err = await bookRes.json();
        throw new Error(err.error || 'Appointment booking failed');
      }

      const bookData = await bookRes.json();
      setIsProcessing(false);
      setShowOtpModal(false);
      onPaymentSuccess(bookData.appointment);
    } catch (err: any) {
      setIsProcessing(false);
      setShowOtpModal(false);
      showToast(err.message || 'Payment transaction failed. Please try again.');
    }
  };

  return (
    <section className="space-y-5 animate-fadeIn">
      {/* Patient Information Form */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-4 space-y-3">
        <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
          <User className="w-4 h-4 text-blue-600" />
          <h3 className="text-sm font-extrabold text-slate-900">Patient Details</h3>
        </div>

        <div className="space-y-2.5">
          <div>
            <label className="text-[11px] font-bold text-slate-600 block mb-1">
              Patient Full Name <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <input
                type="text"
                placeholder="e.g., Rohit Sharma"
                value={patientName}
                onChange={(e) => setPatientName(e.target.value)}
                className="w-full h-10 px-3 pl-8 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium text-slate-800"
              />
              <User className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-3.5" />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <div>
              <label className="text-[11px] font-bold text-slate-600 block mb-1">
                Mobile Number <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <input
                  type="tel"
                  placeholder="98765 43210"
                  maxLength={10}
                  value={patientPhone}
                  onChange={(e) => setPatientPhone(e.target.value.replace(/\D/g, ''))}
                  className="w-full h-10 px-3 pl-8 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium text-slate-800"
                />
                <Phone className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-3.5" />
              </div>
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-600 block mb-1">
                Email Address <span className="text-slate-400 font-normal">(Optional)</span>
              </label>
              <div className="relative">
                <input
                  type="email"
                  placeholder="patient@example.com"
                  value={patientEmail}
                  onChange={(e) => setPatientEmail(e.target.value)}
                  className="w-full h-10 px-3 pl-8 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium text-slate-800"
                />
                <Mail className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-3.5" />
              </div>
            </div>
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-600 block mb-1">
              Medical Note / Chief Complaint <span className="text-slate-400 font-normal">(Optional)</span>
            </label>
            <input
              type="text"
              placeholder="e.g., Sensitivity in lower molar, routine checkup..."
              value={patientNotes}
              onChange={(e) => setPatientNotes(e.target.value)}
              className="w-full h-9 px-3 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium text-slate-800"
            />
          </div>
        </div>
      </div>

      {/* Order Pricing & Coupon */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-4 space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-slate-100">
          <span className="text-sm font-extrabold text-slate-900">Billing Summary</span>
          <span className="text-xs font-bold text-blue-600">
            {selectedDate.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })} · {selectedTime}
          </span>
        </div>

        <div className="space-y-1.5 text-xs">
          {discountAmount > 0 && (
            <div className="flex justify-between text-emerald-600 font-bold pt-1 border-t border-slate-100">
              <span className="flex items-center gap-1">
                <Tag className="w-3.5 h-3.5" /> Coupon Discount ({appliedCoupon})
              </span>
              <span>-₹{discountAmount.toLocaleString('en-IN')}</span>
            </div>
          )}

          <div className="flex justify-between items-center text-sm font-extrabold text-slate-900 pt-2 border-t border-slate-200">
            <span>Total Amount to Pay</span>
            <span className="text-blue-600 text-base">₹{totalPayable.toLocaleString('en-IN')}</span>
          </div>
        </div>

        {/* Promo Code Input */}
        <div className="pt-2">
          <p className="text-[10px] text-slate-500 leading-relaxed mb-3">
            Note: This refundable deposit is fully refundable if canceled at least 30 minutes before your scheduled appointment time.
          </p>
          {appliedCoupon ? (
            <div className="flex items-center justify-between p-2 bg-emerald-50 border border-emerald-200 rounded-xl text-xs font-semibold text-emerald-700">
              <span>Applied: {appliedCoupon}</span>
              <button
                type="button"
                onClick={handleRemoveCoupon}
                className="text-xs text-red-600 hover:underline font-bold"
              >
                Remove
              </button>
            </div>
          ) : (
            <div className="flex gap-2">
              <div className="relative flex-1">
                <input
                  type="text"
                  placeholder="Promo code (e.g. FIRSTCARE)"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                  className="w-full h-9 px-3 pl-8 text-xs uppercase bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 font-bold text-slate-800"
                />
                <Tag className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-3" />
              </div>
              <button
                type="button"
                onClick={handleApplyCoupon}
                className="px-3.5 h-9 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold transition shadow-xs shrink-0"
              >
                Apply
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Payment Method Selector Section */}
      <div className="space-y-2">
        <div className="flex items-center gap-2.5">
          <span className="w-6 h-6 bg-blue-600 text-white font-extrabold rounded-md flex items-center justify-center text-sm shadow-2xs shrink-0">
            4
          </span>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Payment</h2>
        </div>
        <p className="text-slate-500 text-sm font-normal">
          Please choose a payment method
        </p>

        {/* Clean Container Card */}
        <div className="border border-slate-200 rounded-2xl bg-white shadow-2xs overflow-hidden">
          {/* 1. UPI Option */}
          <div className="p-4 sm:p-5">
            <div
              className="flex items-center gap-3.5 cursor-pointer select-none"
              onClick={() => setPaymentMethod('upi')}
            >
              {/* Custom Radio Button */}
              <div className="w-5 h-5 rounded-full border-2 border-slate-900 flex items-center justify-center p-0.5 shrink-0">
                {paymentMethod === 'upi' && (
                  <div className="w-2.5 h-2.5 rounded-full bg-slate-900" />
                )}
              </div>

              <Smartphone className="w-5 h-5 text-slate-800 shrink-0" />
              <span className="font-bold text-slate-950 text-base">UPI</span>
            </div>

            {paymentMethod === 'upi' && (
              <div className="mt-4 space-y-2.5 pl-0 sm:pl-1 animate-fadeIn">
                <p className="text-sm text-slate-500 font-normal">
                  Select your preferred UPI app
                </p>

                {/* Vertical stack of 4 UPI apps without any brand logos */}
                <div className="space-y-2">
                  {[
                    { id: 'gpay', label: 'Google Pay' },
                    { id: 'phonepe', label: 'PhonePe' },
                    { id: 'bhim', label: 'BHIM' },
                    { id: 'paytm', label: 'Paytm' }
                  ].map((app) => {
                    const isSelected = selectedUpiApp === app.id;
                    return (
                      <button
                        key={app.id}
                        type="button"
                        onClick={() => setSelectedUpiApp(app.id as any)}
                        className={`w-full px-4 py-3 rounded-xl border text-sm flex items-center justify-between transition ${
                          isSelected
                            ? 'border-2 border-slate-900 bg-slate-50/70 text-slate-900 font-bold shadow-2xs'
                            : 'border-slate-200 hover:border-slate-300 bg-white text-slate-800 font-medium'
                        }`}
                      >
                        <span className="text-sm">{app.label}</span>
                        {isSelected && (
                          <Check className="w-4 h-4 text-slate-900 stroke-[2.5]" />
                        )}
                      </button>
                    );
                  })}
                </div>

                {/* Additional UPI options: Custom UPI ID and QR code */}
                <div className="pt-2 flex items-center justify-between text-xs font-semibold text-slate-500">
                  <button
                    type="button"
                    onClick={() => setSelectedUpiApp(selectedUpiApp === 'custom' ? 'gpay' : 'custom')}
                    className="hover:text-slate-900 text-slate-600 transition underline underline-offset-2"
                  >
                    {selectedUpiApp === 'custom' ? 'Hide Custom UPI' : 'Enter other UPI ID / VPA'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowQrCode(!showQrCode)}
                    className="hover:text-blue-600 text-blue-600 transition flex items-center gap-1 font-bold"
                  >
                    <QrCode className="w-3.5 h-3.5" />
                    <span>{showQrCode ? 'Hide QR' : 'Show UPI QR'}</span>
                  </button>
                </div>

                {selectedUpiApp === 'custom' && (
                  <div className="mt-2 animate-fadeIn">
                    <input
                      type="text"
                      placeholder="e.g. mobile@upi or username@okhdfcbank"
                      value={customUpiId}
                      onChange={(e) => setCustomUpiId(e.target.value)}
                      className="w-full h-10 px-3.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-900 font-medium"
                    />
                  </div>
                )}

                {showQrCode && (
                  <div className="mt-2 p-3 bg-slate-50 rounded-xl text-center space-y-1.5 border border-slate-200 animate-fadeIn">
                    <div className="w-32 h-32 bg-white mx-auto p-2 rounded-xl shadow-xs border border-slate-200 flex items-center justify-center">
                      <QrCode className="w-24 h-24 text-slate-900" />
                    </div>
                    <span className="text-[11px] font-bold text-slate-600 block">
                      Scan with any UPI App · ₹{totalPayable.toLocaleString('en-IN')}
                    </span>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Divider line */}
          <div className="border-t border-slate-200" />

          {/* 2. Cards Option */}
          <div className="p-4 sm:p-5">
            <div
              className="flex items-center justify-between cursor-pointer select-none"
              onClick={() => setPaymentMethod('card')}
            >
              <div className="flex items-center gap-3.5">
                {/* Custom Radio Button */}
                <div className="w-5 h-5 rounded-full border-2 border-slate-400 flex items-center justify-center p-0.5 shrink-0">
                  {paymentMethod === 'card' && (
                    <div className="w-2.5 h-2.5 rounded-full bg-slate-900" />
                  )}
                </div>
                <CreditCard className="w-5 h-5 text-slate-900 stroke-[1.8]" />
                <span className="font-bold text-slate-950 text-base">Credit / Debit Card</span>
              </div>
            </div>

            {paymentMethod === 'card' && (
              <div className="mt-4 space-y-3.5 pt-3 border-t border-slate-100 animate-fadeIn">
                <div className="relative">
                  <label className="text-[11px] font-bold text-slate-600 block mb-1">Card Number</label>
                  <div className="relative">
                    <input
                      type="text"
                      placeholder="1234 5678 9012 3456"
                      maxLength={19}
                      value={cardNumber}
                      onChange={handleCardNumberChange}
                      className="w-full h-10 border border-slate-300 rounded-xl px-3 pl-9 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900 font-medium"
                    />
                    <CreditCard className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-bold text-slate-600 block mb-1">Expiration (MM/YY)</label>
                    <input
                      type="text"
                      placeholder="MM/YY"
                      maxLength={5}
                      value={cardExpiry}
                      onChange={handleExpiryChange}
                      className="w-full h-10 border border-slate-300 rounded-xl px-3 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900 font-medium text-center"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-bold text-slate-600 block mb-1">CVV / CVC</label>
                    <input
                      type="password"
                      placeholder="•••"
                      maxLength={4}
                      value={cardCvv}
                      onChange={(e) => setCardCvv(e.target.value.replace(/\D/g, ''))}
                      className="w-full h-10 border border-slate-300 rounded-xl px-3 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900 font-medium text-center"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-600 block mb-1">Cardholder Name</label>
                  <input
                    type="text"
                    placeholder="Name as printed on card"
                    value={cardHolder}
                    onChange={(e) => setCardHolder(e.target.value)}
                    className="w-full h-10 border border-slate-300 rounded-xl px-3 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900 font-medium"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Divider line */}
          <div className="border-t border-slate-200" />

          {/* 3. Net Banking */}
          <div className="p-4 sm:p-5">
            <div
              className="flex items-center gap-3.5 cursor-pointer select-none"
              onClick={() => setPaymentMethod('netbanking')}
            >
              <div className="w-5 h-5 rounded-full border-2 border-slate-400 flex items-center justify-center p-0.5 shrink-0">
                {paymentMethod === 'netbanking' && (
                  <div className="w-2.5 h-2.5 rounded-full bg-slate-900" />
                )}
              </div>
              <Building className="w-5 h-5 text-slate-900 stroke-[1.8]" />
              <span className="font-bold text-slate-950 text-base">Net Banking</span>
            </div>

            {paymentMethod === 'netbanking' && (
              <div className="mt-4 space-y-3.5 pt-3 border-t border-slate-100 animate-fadeIn">
                <div className="flex items-center justify-between">
                  <p className="text-xs text-slate-500 font-medium">Select your bank from top institutions</p>
                  {selectedBank && (
                    <span className="text-[11px] font-bold text-blue-700 bg-blue-50 border border-blue-100 px-2 py-0.5 rounded-md">
                      Selected: {selectedBank}
                    </span>
                  )}
                </div>

                {/* Popular Bank Buttons */}
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {[
                    'HDFC Bank',
                    'State Bank of India',
                    'ICICI Bank',
                    'Axis Bank',
                    'Kotak Mahindra',
                    'Punjab National Bank'
                  ].map((bank) => {
                    const isSelected = selectedBank === bank;
                    return (
                      <button
                        key={bank}
                        type="button"
                        onClick={() => {
                          setSelectedBank(bank);
                          showToast(`Selected ${bank} for Net Banking`);
                        }}
                        className={`p-2.5 rounded-xl text-xs text-left transition flex items-center justify-between ${
                          isSelected
                            ? 'border-2 border-slate-900 bg-slate-50 text-slate-900 font-bold shadow-2xs'
                            : 'border border-slate-200 hover:border-slate-300 text-slate-700 bg-white hover:bg-slate-50 font-medium'
                        }`}
                      >
                        <span className="truncate">{bank}</span>
                        {isSelected && <Check className="w-3.5 h-3.5 text-slate-900 shrink-0 stroke-[2.5]" />}
                      </button>
                    );
                  })}
                </div>

                {/* Dropdown for other banks */}
                <div className="pt-1">
                  <label className="text-[11px] font-bold text-slate-600 block mb-1">
                    Or choose from all other banks
                  </label>
                  <select
                    value={selectedBank}
                    onChange={(e) => {
                      setSelectedBank(e.target.value);
                      showToast(`Selected ${e.target.value}`);
                    }}
                    className="w-full h-10 px-3 text-xs bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-900 font-medium text-slate-900"
                  >
                    <option value="HDFC Bank">HDFC Bank</option>
                    <option value="State Bank of India">State Bank of India (SBI)</option>
                    <option value="ICICI Bank">ICICI Bank</option>
                    <option value="Axis Bank">Axis Bank</option>
                    <option value="Kotak Mahindra">Kotak Mahindra Bank</option>
                    <option value="Punjab National Bank">Punjab National Bank</option>
                    <option value="Bank of Baroda">Bank of Baroda</option>
                    <option value="Canara Bank">Canara Bank</option>
                    <option value="Union Bank of India">Union Bank of India</option>
                    <option value="IndusInd Bank">IndusInd Bank</option>
                    <option value="IDBI Bank">IDBI Bank</option>
                    <option value="Yes Bank">Yes Bank</option>
                    <option value="Federal Bank">Federal Bank</option>
                  </select>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Pay Now Button */}
      <div className="pt-2">
        <button
          type="button"
          onClick={handleInitiatePayment}
          disabled={isProcessing}
          className="w-full py-3.5 bg-slate-900 hover:bg-black text-white font-extrabold rounded-2xl shadow-xl flex items-center justify-center gap-2 text-sm active:scale-98 transition disabled:opacity-50"
        >
          <Lock className="w-4 h-4 text-emerald-400" />
          <span>Confirm & Pay ₹{totalPayable.toLocaleString('en-IN')}</span>
        </button>
        <div className="flex items-center justify-center gap-2 mt-2.5 text-[11px] text-slate-400 font-medium">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
          <span>100% Secure Payment · Instant Booking Receipt & SMS Confirmation</span>
        </div>
      </div>

      {/* Realistic 3DS OTP Modal for Card Payments */}
      {showOtpModal && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4"
        >
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full space-y-4 shadow-2xl border border-slate-200 animate-scaleUp">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-blue-600" />
                <span className="font-extrabold text-sm text-slate-900">3D Secure Bank Auth</span>
              </div>
              <span className="text-[11px] text-slate-400 font-semibold">256-bit Secure</span>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              A 4-digit verification OTP has been sent to your registered mobile ending in{' '}
              <span className="font-bold text-slate-900">•••• 3421</span>.
            </p>

            <div className="p-3 bg-blue-50 border border-blue-100 rounded-xl text-xs space-y-1">
              <div className="flex justify-between text-slate-600">
                <span>Merchant:</span>
                <span className="font-bold text-slate-800">Aura Clinic - Dr. Ananya Rao</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Amount:</span>
                <span className="font-bold text-blue-600">₹{totalPayable.toLocaleString('en-IN')}</span>
              </div>
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-600 block mb-1">Enter OTP (Demo: 4928)</label>
              <input
                type="text"
                maxLength={4}
                value={otpCode}
                onChange={(e) => setOtpCode(e.target.value)}
                className="w-full h-11 text-center font-mono text-lg tracking-widest bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 font-bold"
              />
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowOtpModal(false)}
                className="w-1/2 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={executePaymentTransaction}
                disabled={isProcessing}
                className="w-1/2 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1 shadow-sm"
              >
                {isProcessing ? 'Verifying...' : 'Submit OTP'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Gateway Processing Overlay */}
      {isProcessing && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4"
        >
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full text-center space-y-4 shadow-2xl border border-slate-200 animate-scaleUp">
            <div className="w-14 h-14 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mx-auto ring-8 ring-blue-50 animate-pulse">
              <Lock className="w-7 h-7" />
            </div>

            <div>
              <h3 className="text-base font-extrabold text-slate-900">
                {processingStage === 'handshake' && 'Connecting to Payment Gateway...'}
                {processingStage === 'gateway' && 'Launching UPI Payment App...'}
                {processingStage === 'confirming' && 'Securing Appointment Slot...'}
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Please do not close or refresh this window.
              </p>
            </div>

            <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
              <div
                className="bg-blue-600 h-full transition-all duration-500"
                style={{
                  width:
                    processingStage === 'handshake'
                      ? '35%'
                      : processingStage === 'gateway'
                      ? '70%'
                      : '95%'
                }}
              ></div>
            </div>

            <span className="text-[11px] text-slate-400 font-semibold block">
              Safe & Encrypted 256-bit Healthcare Channel
            </span>
          </div>
        </div>
      )}

      {/* UPI Payment Completion Confirmation Modal */}
      {showUpiConfirmModal && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn"
        >
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full text-center space-y-4 shadow-2xl border border-slate-200 animate-scaleUp">
            <div className="w-14 h-14 bg-amber-50 text-amber-600 rounded-full flex items-center justify-center mx-auto ring-8 ring-amber-50">
              <Smartphone className="w-7 h-7" />
            </div>

            <div>
              <h3 className="text-base font-extrabold text-slate-900">
                Complete Payment in {selectedUpiApp.toUpperCase()}
              </h3>
              <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                Please finish your payment of <strong className="text-slate-900">₹{pendingOrderData?.totalAmount}</strong> in your UPI app, then click below to generate your appointment ticket.
              </p>
            </div>

            <div className="space-y-2 pt-2">
              <button
                type="button"
                onClick={async () => {
                  setShowUpiConfirmModal(false);
                  setIsProcessing(true);
                  setProcessingStage('confirming');
                  try {
                    const payRes = await fetch('/api/payments/process', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({
                        orderId: pendingOrderData.orderId,
                        amount: pendingOrderData.totalAmount,
                        currency: 'INR',
                        method: 'upi',
                        upiApp: selectedUpiApp.toUpperCase()
                      })
                    });

                    if (!payRes.ok) {
                      const err = await payRes.json();
                      throw new Error(err.error || 'Payment verification failed');
                    }

                    const payData = await payRes.json();
                    await new Promise((r) => setTimeout(r, 600));

                    const formattedDate = `${selectedDate.getFullYear()}-${String(selectedDate.getMonth() + 1).padStart(
                      2,
                      '0'
                    )}-${String(selectedDate.getDate()).padStart(2, '0')}`;

                    const bookRes = await fetch('/api/appointments/book', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({
                        patientName,
                        patientPhone,
                        patientEmail,
                        patientNotes,
                        serviceIds: selectedServices.map((s) => s.id),
                        date: formattedDate,
                        time: selectedTime,
                        paymentTransactionId: payData.transaction.id,
                        couponCode: appliedCoupon ? couponCode : undefined
                      })
                    });

                    if (!bookRes.ok) {
                      const err = await bookRes.json();
                      throw new Error(err.error || 'Appointment booking failed');
                    }

                    const bookData = await bookRes.json();
                    setIsProcessing(false);
                    onPaymentSuccess(bookData.appointment);
                  } catch (err: any) {
                    setIsProcessing(false);
                    showToast(err.message || 'Payment verification failed. Please try again.');
                  }
                }}
                className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-extrabold rounded-2xl text-xs shadow-md transition"
              >
                I have paid · Generate Ticket ✅
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowUpiConfirmModal(false);
                  setIsProcessing(false);
                }}
                className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-2xl text-xs transition"
              >
                Cancel & Return
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
