import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { DatabaseSchema, DoctorProfile, TreatmentService, PatientReview, Appointment, PaymentTransaction } from './types.js';

const DB_FILE_PATH = path.resolve(process.cwd(), 'data', 'db.json');

const INITIAL_DOCTOR: DoctorProfile = {
  id: 'dr-ananya-rao',
  name: 'Dr. Ananya Rao',
  title: 'MBBS | BDS | Cardiologist',
  specialties: ['Endodontics', 'Orthodontics', 'Preventive Dentistry', 'Cardiovascular Screening'],
  experienceYears: 10,
  rating: 4.9,
  reviewCount: 284,
  avatarUrl: '/src/assets/images/doctor_ananya_portrait_1790167197977.jpg',
  clinicName: 'Aura Medical & Dental Wellness Centre',
  clinicAddress: 'Suite 402, 100ft Road, Indiranagar, Bangalore, Karnataka 560038',
  clinicOverview: 'Modern multispecialty clinic offering comprehensive dental, orthodontic, and cardiovascular consultation services equipped with digital intraoral imaging, ultrasonic equipment, and cardiac diagnostic facilities.',
  clinicImages: [
    {
      src: '/src/assets/images/clinic_modern_operatory_1790167212308.jpg',
      title: 'Clinic Consultation & Operatory Suite',
      caption: 'Sterile, modern operatory designed for comprehensive patient safety and comfort.'
    },
    {
      src: '/src/assets/images/treatment_root_canal_1790167223532.jpg',
      title: 'Endodontic Precision Operatory',
      caption: 'Advanced digital imaging and rotary endodontic equipment for painless root canal therapies.'
    },
    {
      src: '/src/assets/images/treatment_deep_cleaning_1790167236130.jpg',
      title: 'Hygiene & Preventive Dental Suite',
      caption: 'Ultrasonic scaling instruments with high standards of autoclaved sterilization.'
    },
    {
      src: '/src/assets/images/treatment_orthodontic_braces_1790167247551.jpg',
      title: 'Orthodontic Alignment Suite',
      caption: 'Custom digital aligners and precision ceramic bracket setups.'
    }
  ],
  timings: 'Daily: 8:00 AM - 9:00 PM',
  phone: '+91 (080) 4920-8822',
  email: 'appointments@ananyaraoclinic.in'
};

const INITIAL_SERVICES: TreatmentService[] = [
  {
    id: 'rc',
    name: 'Root Canal',
    category: 'Endodontics',
    durationMinutes: 60,
    description: 'Infection treatment and restorative care for compromised tooth roots using computerized apex locators and painless anesthesia.',
    imageUrl: '/src/assets/images/treatment_root_canal_1790167223532.jpg',
    includes: [
      'Pre-op Digital RVG X-Ray',
      'Computerized Apex Locator canal shaping',
      'Biocompatible Gutta-Percha obturation',
      'Temporary restorative seal'
    ]
  },
  {
    id: 'dc',
    name: 'Deep Cleaning',
    category: 'Preventive',
    durationMinutes: 45,
    description: 'Professional ultrasonic scaling, subgingival plaque and tartar removal, followed by gentle prophylactic enamel polishing.',
    imageUrl: '/src/assets/images/treatment_deep_cleaning_1790167236130.jpg',
    includes: [
      'Comprehensive Gum Health Assessment',
      'Full-mouth Ultrasonic Piezo Scaling',
      'Air-flow Polishing for stain removal',
      'Fluoride enamel strengthening coat'
    ]
  },
  {
    id: 'braces',
    name: 'Orthodontic Braces',
    category: 'Orthodontics',
    durationMinutes: 90,
    description: 'Orthodontic alignment for smile correction using premium ceramic brackets or clear aligner options designed for all age groups.',
    imageUrl: '/src/assets/images/treatment_orthodontic_braces_1790167247551.jpg',
    includes: [
      'Digital Smile Scan & Cephalometric Analysis',
      'Full Bracket Bonding session',
      'Initial Nickel-Titanium archwires',
      'Orthodontic hygiene kit & emergency wax'
    ]
  },
  {
    id: 'cardio',
    name: 'Cardiac Health Consultation',
    category: 'Cardiology',
    durationMinutes: 45,
    description: 'Comprehensive preventive heart checkup, resting 12-lead electrocardiogram, blood pressure evaluation, and cardiac risk assessment.',
    imageUrl: '/src/assets/images/clinic_modern_operatory_1790167212308.jpg',
    includes: [
      '12-Lead Digital Electrocardiogram (ECG)',
      'Multi-point Blood Pressure monitoring',
      'Cardiovascular Risk Profile analysis',
      'Personalized dietary & medication review'
    ]
  },
  {
    id: 'whitening',
    name: 'Laser Teeth Whitening',
    category: 'Cosmetic',
    durationMinutes: 60,
    description: 'In-clinic advanced LED laser activation for lightening enamel stains up to 5-8 shades in a single comfortable sitting.',
    imageUrl: '/src/assets/images/treatment_deep_cleaning_1790167236130.jpg',
    includes: [
      'Gingival barrier protection',
      'Medical-grade carbamide peroxide gel',
      'Triple-pass LED light activation',
      'Post-treatment sensitivity guard'
    ]
  }
];

const INITIAL_REVIEWS: PatientReview[] = [
  {
    id: 'rev-1',
    patientName: 'Rahul K.',
    initials: 'RK',
    rating: 5,
    date: '2 weeks ago',
    treatment: 'Root Canal Treatment',
    comment: 'Dr. Ananya was exceptionally polite and explained every step of the Root Canal procedure. Painless experience with zero discomfort afterwards!',
    verified: true,
    avatarColor: 'bg-blue-600'
  },
  {
    id: 'rev-2',
    patientName: 'Priya Sharma',
    initials: 'PS',
    rating: 5,
    date: '1 month ago',
    treatment: 'Deep Cleaning & Scaling',
    comment: 'Impeccably clean clinic and courteous front desk staff. Scaling and polishing was handled with utmost gentleness and care.',
    verified: true,
    avatarColor: 'bg-emerald-600'
  },
  {
    id: 'rev-3',
    patientName: 'Dr. Arvind Nair',
    initials: 'AN',
    rating: 5,
    date: '3 weeks ago',
    treatment: 'Cardiac Health Consultation',
    comment: 'As a fellow physician, I was thoroughly impressed by Dr. Rao’s thorough cardiovascular evaluation and clear, evidence-based recommendations.',
    verified: true,
    avatarColor: 'bg-amber-600'
  },
  {
    id: 'rev-4',
    patientName: 'Sneha Menon',
    initials: 'SM',
    rating: 5,
    date: '1 month ago',
    treatment: 'Orthodontic Braces Setup',
    comment: 'Started my ceramic braces journey here. The digital simulation of my teeth alignment was incredible, and the pricing was completely transparent.',
    verified: true,
    avatarColor: 'bg-indigo-600'
  },
  {
    id: 'rev-5',
    patientName: 'Vikram Patel',
    initials: 'VP',
    rating: 4,
    date: '2 months ago',
    treatment: 'Root Canal & Laser Whitening',
    comment: 'Great clinical expertise and state-of-the-art facility. Appointment started right on time without waiting.',
    verified: true,
    avatarColor: 'bg-purple-600'
  }
];

const INITIAL_BLOCKED_SLOTS: Array<{ date: string; time: string; reason: string }> = [];

class DatabaseManager {
  private data: DatabaseSchema;

  constructor() {
    this.data = this.loadData();
  }

  private loadData(): DatabaseSchema {
    try {
      const dataDir = path.dirname(DB_FILE_PATH);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      if (fs.existsSync(DB_FILE_PATH)) {
        const raw = fs.readFileSync(DB_FILE_PATH, 'utf-8');
        const parsed = JSON.parse(raw);
        // Clean out legacy hardcoded lunch blocks so 1:00 PM is never booked forever
        const cleanBlockedSlots = (parsed.blockedSlots || []).filter(
          (s: any) => s.date !== 'all' && s.time !== '01:00 PM' && s.time !== '01:30 PM' && s.time !== '02:00 PM'
        );
        return {
          doctor: { ...(parsed.doctor || INITIAL_DOCTOR), timings: 'Daily: 8:00 AM - 9:00 PM' },
          services: parsed.services || INITIAL_SERVICES,
          reviews: parsed.reviews || INITIAL_REVIEWS,
          appointments: parsed.appointments || [],
          transactions: parsed.transactions || [],
          blockedSlots: cleanBlockedSlots
        };
      }
    } catch (err) {
      console.error('Error loading database from file, initializing fresh store:', err);
    }

    const defaultData: DatabaseSchema = {
      doctor: INITIAL_DOCTOR,
      services: INITIAL_SERVICES,
      reviews: INITIAL_REVIEWS,
      appointments: [],
      transactions: [],
      blockedSlots: []
    };
    this.saveData(defaultData);
    return defaultData;
  }

  private saveData(data: DatabaseSchema) {
    try {
      const dataDir = path.dirname(DB_FILE_PATH);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      fs.writeFileSync(DB_FILE_PATH, JSON.stringify(data, null, 2), 'utf-8');
    } catch (err) {
      console.error('Error saving database to file:', err);
    }
  }

  public getDoctor(): DoctorProfile {
    return this.data.doctor;
  }

  public getServices(): TreatmentService[] {
    return this.data.services;
  }

  public getServiceById(id: string): TreatmentService | undefined {
    return this.data.services.find(s => s.id === id);
  }

  public getReviews(): PatientReview[] {
    return this.data.reviews;
  }

  public addReview(review: Omit<PatientReview, 'id' | 'date' | 'verified'>): PatientReview {
    const newReview: PatientReview = {
      ...review,
      id: `rev-${Date.now()}`,
      date: 'Just now',
      verified: true,
      avatarColor: 'bg-blue-600'
    };
    this.data.reviews.unshift(newReview);
    this.data.doctor.reviewCount += 1;
    this.saveData(this.data);
    return newReview;
  }

  public getAppointments(): Appointment[] {
    this.updateCompletedAppointments();
    return this.data.appointments;
  }

  public getAppointmentById(id: string): Appointment | undefined {
    return this.data.appointments.find(a => a.id === id || a.appointmentNumber === id);
  }

  public getAppointmentTimeRange(apt: {
    date: string;
    time: string;
    services?: Array<{ duration?: number }>;
  }): { start: Date; end: Date; durationMinutes: number } | null {
    if (!apt.date || !apt.time) return null;
    const match = apt.time.match(/(\d+):(\d+)\s*(AM|PM)/i);
    if (!match) return null;

    let hours = parseInt(match[1], 10);
    const minutes = parseInt(match[2], 10);
    const period = match[3].toUpperCase();

    if (period === 'PM' && hours < 12) hours += 12;
    if (period === 'AM' && hours === 12) hours = 0;

    const parts = apt.date.split('-').map(Number);
    if (parts.length < 3 || parts.some(isNaN)) return null;
    const [y, m, d] = parts;

    const start = new Date(y, m - 1, d, hours, minutes, 0, 0);

    let durationMinutes = 45;
    if (apt.services && apt.services.length > 0) {
      const sum = apt.services.reduce((acc, s) => acc + (s.duration || 45), 0);
      if (sum > 0) durationMinutes = sum;
    }
    const end = new Date(start.getTime() + durationMinutes * 60 * 1000);
    return { start, end, durationMinutes };
  }

  public formatTime12h(date: Date): string {
    let hours = date.getHours();
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const period = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12 || 12;
    return `${String(hours).padStart(2, '0')}:${minutes} ${period}`;
  }

  public formatHourMinute12h(hours: number, minutes: number): string {
    const period = hours >= 12 ? 'PM' : 'AM';
    const h12 = hours % 12 || 12;
    return `${String(h12).padStart(2, '0')}:${String(minutes).padStart(2, '0')} ${period}`;
  }

  public updateCompletedAppointments(): number {
    const now = new Date();
    let updatedCount = 0;
    this.data.appointments.forEach(apt => {
      if (apt.status === 'confirmed') {
        const range = this.getAppointmentTimeRange(apt);
        if (range && now >= range.end) {
          apt.status = 'completed';
          updatedCount++;
        }
      }
    });

    if (updatedCount > 0) {
      this.saveData(this.data);
    }
    return updatedCount;
  }

  public getUnavailableSlots(date: string, durationMinutes: number = 45): Array<{
    time: string;
    reason: string;
    reopensAt?: string;
    durationMinutes?: number;
    isOccupiedNow?: boolean;
  }> {
    this.updateCompletedAppointments();
    const list: Array<{
      time: string;
      reason: string;
      reopensAt?: string;
      durationMinutes?: number;
      isOccupiedNow?: boolean;
    }> = [];
    const now = new Date();

    // Clinic Operating Hours: 8:00 AM to 9:00 PM
    const CLINIC_OPEN_MINUTES = 8 * 60; // 8:00 AM
    const CLINIC_CLOSE_MINUTES = 21 * 60; // 21:00 (9:00 PM)

    const dateParts = date.split('-').map(Number);
    const isValidDate = dateParts.length === 3 && !dateParts.some(isNaN);

    // Evaluate all 15-minute slot intervals across 24 hours (00:00 to 23:45)
    for (let h = 0; h <= 23; h++) {
      for (const m of [0, 15, 30, 45]) {
        const slotStartMinutes = h * 60 + m;
        const slotEndMinutes = slotStartMinutes + durationMinutes;
        const timeStr = this.formatHourMinute12h(h, m);

        // 1. If service duration extends past clinic closing time (9:00 PM)
        // e.g. 8:30 PM + 45 min = 9:15 PM > 9:00 PM
        // Removed restriction for 8:30 PM slot
        if (slotEndMinutes > CLINIC_CLOSE_MINUTES && !(h === 20 && m === 30)) {
          list.push({
            time: timeStr,
            reason: 'Clinic Closes 9:00 PM',
            durationMinutes
          });
          continue;
        }

        // Before opening hours
        if (slotStartMinutes < CLINIC_OPEN_MINUTES) {
          list.push({
            time: timeStr,
            reason: 'Opens at 8:00 AM',
            durationMinutes
          });
          continue;
        }

        // 2. Check collision with active confirmed bookings
        if (isValidDate) {
          const [y, mon, d] = dateParts;
          const candidateStart = new Date(y, mon - 1, d, h, m, 0, 0);
          const candidateEnd = new Date(candidateStart.getTime() + durationMinutes * 60 * 1000);

          for (const apt of this.data.appointments) {
            if (apt.date === date && apt.status === 'confirmed') {
              const range = this.getAppointmentTimeRange(apt);
              if (range) {
                // If the service has finished its exact duration, it has already reopened
                if (now >= range.end) continue;

                // Check interval overlap: max(start1, start2) < min(end1, end2)
                const isOverlapping =
                  Math.max(candidateStart.getTime(), range.start.getTime()) <
                  Math.min(candidateEnd.getTime(), range.end.getTime());

                if (isOverlapping) {
                  const endFormatted = this.formatTime12h(range.end);
                  list.push({
                    time: timeStr,
                    reason: `Reopens at ${endFormatted}`,
                    reopensAt: range.end.toISOString(),
                    durationMinutes: range.durationMinutes,
                    isOccupiedNow: now >= range.start && now < range.end
                  });
                  break;
                }
              }
            }
          }
        }
      }
    }

    return list;
  }

  public reopenSlot(id: string): Appointment {
    const apt = this.data.appointments.find(a => a.id === id || a.appointmentNumber === id);
    if (!apt) {
      throw new Error('Appointment not found');
    }
    apt.status = 'completed';
    this.saveData(this.data);
    return apt;
  }

  public createPaymentOrder(params: {
    serviceIds: string[];
    couponCode?: string;
  }): {
    orderId: string;
    services: TreatmentService[];
    baseAmount: number;
    discount: number;
    gstAmount: number;
    totalAmount: number;
    currency: string;
    appliedCoupon?: string;
  } {
    const selectedServices: TreatmentService[] = [];
    for (const sid of params.serviceIds) {
      const svc = this.getServiceById(sid);
      if (svc) selectedServices.push(svc);
    }

    if (selectedServices.length === 0) {
      throw new Error('At least one valid service must be selected');
    }

    const baseAmount = 399; // ₹399 refundable deposit
    let discount = 0;
    let appliedCoupon: string | undefined = undefined;

    if (params.couponCode) {
      const code = params.couponCode.trim().toUpperCase();
      // Cap discount at ₹50
      discount = Math.min(50, Math.round(baseAmount * 0.10)); // 10% or ₹50, whichever is less
      appliedCoupon = `${code} (Discount applied)`;
    }

    const discountedBase = Math.max(0, baseAmount - discount);
    const gstAmount = 0; 
    const totalAmount = discountedBase + gstAmount;

    const orderId = `ORD-${Date.now().toString().slice(-6)}-${crypto.randomBytes(2).toString('hex').toUpperCase()}`;

    return {
      orderId,
      services: selectedServices,
      baseAmount,
      discount,
      gstAmount,
      totalAmount,
      currency: 'INR',
      appliedCoupon
    };
  }

  public processPayment(params: {
    orderId: string;
    amount: number;
    currency: string;
    method: 'upi' | 'card' | 'netbanking';
    upiApp?: string;
    upiId?: string;
    cardLast4?: string;
    cardBrand?: string;
  }): PaymentTransaction {
    const transactionRef = `TXN-IND-${Date.now()}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
    const receiptNumber = `REC-${new Date().getFullYear()}-${Math.floor(100000 + Math.random() * 900000)}`;

    const transaction: PaymentTransaction = {
      id: `txn-${Date.now()}`,
      orderId: params.orderId,
      amount: params.amount,
      currency: params.currency || 'INR',
      method: params.method,
      upiApp: params.upiApp,
      upiId: params.upiId,
      cardLast4: params.cardLast4,
      cardBrand: params.cardBrand || (params.method === 'card' ? 'Visa' : undefined),
      status: 'success',
      transactionRef,
      createdAt: new Date().toISOString(),
      receiptNumber
    };

    this.data.transactions.push(transaction);
    this.saveData(this.data);
    return transaction;
  }

  public bookAppointment(params: {
    patientName: string;
    patientPhone: string;
    patientEmail?: string;
    patientNotes?: string;
    serviceIds: string[];
    date: string;
    time: string;
    paymentTransactionId: string;
    couponCode?: string;
  }): Appointment {
    // Compute total duration of requested services
    const services = params.serviceIds.map(id => this.getServiceById(id)).filter(Boolean) as TreatmentService[];
    const totalDuration = services.reduce((sum, s) => sum + (s.durationMinutes || 45), 0) || 45;

    // Validate slot availability considering duration and clinic working hours
    const unavail = this.getUnavailableSlots(params.date, totalDuration);
    const matchedUnavail = unavail.find(u => u.time === params.time);
    if (matchedUnavail) {
      throw new Error(`The requested slot ${params.time} cannot be booked: ${matchedUnavail.reason}`);
    }

    // Verify payment transaction
    const txn = this.data.transactions.find(t => t.id === params.paymentTransactionId || t.transactionRef === params.paymentTransactionId);
    if (!txn || txn.status !== 'success') {
      throw new Error('Valid verified payment transaction is required to confirm appointment');
    }

    // Compute order pricing
    const orderData = this.createPaymentOrder({
      serviceIds: params.serviceIds,
      couponCode: params.couponCode
    });

    const appointmentNumber = `APT-${Date.now().toString().slice(-5)}${Math.floor(10 + Math.random() * 90)}`;
    const appointmentId = `apt-${Date.now()}-${crypto.randomBytes(2).toString('hex')}`;

    const appointment: Appointment = {
      id: appointmentId,
      appointmentNumber,
      patientName: params.patientName.trim(),
      patientPhone: params.patientPhone.trim(),
      patientEmail: params.patientEmail ? params.patientEmail.trim() : '',
      patientNotes: params.patientNotes?.trim() || '',
      serviceIds: orderData.services.map(s => s.id),
      serviceNames: orderData.services.map(s => s.name),
      services: orderData.services.map(s => ({
        id: s.id,
        name: s.name,
        price: 0, 
        duration: s.durationMinutes
      })),
      baseAmount: orderData.baseAmount,
      discount: orderData.discount,
      couponApplied: orderData.appliedCoupon,
      gstAmount: orderData.gstAmount,
      totalAmount: orderData.totalAmount,
      currency: 'INR',
      date: params.date,
      time: params.time,
      status: 'confirmed',
      paymentId: txn.id,
      paymentMethod: txn.method,
      paymentDetails: {
        transactionRef: txn.transactionRef,
        paidAt: txn.createdAt,
        receiptNumber: txn.receiptNumber,
        upiApp: txn.upiApp,
        cardLast4: txn.cardLast4
      },
      createdAt: new Date().toISOString()
    };

    // Associate appointment ID with transaction
    txn.appointmentId = appointmentId;

    this.data.appointments.unshift(appointment);
    this.saveData(this.data);

    // Free Email Ticket Dispatch simulation
    const emailSubject = `Your Dental Clinic Appointment Ticket #${appointment.appointmentNumber}`;
    const emailBody = `Dear ${appointment.patientName},

Your appointment has been successfully confirmed and paid!

Appointment Details:
- Ticket Number: #${appointment.appointmentNumber}
- Services: ${appointment.serviceNames.join(', ')}
- Date: ${appointment.date}
- Time: ${appointment.time}
- Total Paid: ₹${appointment.totalAmount}
- Status: Confirmed ✅

You can request a full refund or cancellation up to 30 minutes before your scheduled appointment start time.

Thank you for choosing our clinic!`;

    console.log(`[EMAIL TICKET DISPATCH] Sent to ${appointment.patientEmail}:\nSubject: ${emailSubject}\n\n${emailBody}`);

    // Free WhatsApp Auto-Message Push simulation & notification trigger
    const whatsappMessage = `*🦷 Dental Clinic Booking Confirmed!*
Ticket: #${appointment.appointmentNumber}
Patient: ${appointment.patientName}
Services: ${appointment.serviceNames.join(', ')}
Date: ${appointment.date}
Time: ${appointment.time}
Total Paid: ₹${appointment.totalAmount}
Status: Confirmed ✅

_Thank you for choosing our clinic! You can cancel/refund up to 30 mins before your slot._`;
    
    console.log(`[WHATSAPP AUTO-PUSH] Sent to +91 ${appointment.patientPhone}: \n${whatsappMessage}`);

    return appointment;
  }

  public cancelAppointment(id: string, reason?: string): Appointment {
    const apt = this.data.appointments.find(a => a.id === id || a.appointmentNumber === id);
    if (!apt) {
      throw new Error('Appointment not found');
    }
    if (apt.status === 'cancelled' || apt.status === 'refunded') {
      return apt;
    }

    // 30-minute before refund policy check
    const range = this.getAppointmentTimeRange(apt);
    if (range) {
      const now = new Date();
      // Refund cutoff is 30 minutes BEFORE appointment start time
      const refundCutoff = new Date(range.start.getTime() - 30 * 60 * 1000);
      if (now > refundCutoff) {
        throw new Error(`Refund window closed. Cancellations with refund must be made at least 30 minutes before the appointment start time (${apt.time}).`);
      }
    }

    apt.status = 'refunded';
    if (reason) {
      apt.patientNotes = (apt.patientNotes ? apt.patientNotes + ' | ' : '') + `Refunded & Cancelled: ${reason}`;
    } else {
      apt.patientNotes = (apt.patientNotes ? apt.patientNotes + ' | ' : '') + `Refunded & Cancelled (Within 30-min prior policy)`;
    }

    this.saveData(this.data);
    return apt;
  }
}

export const db = new DatabaseManager();
