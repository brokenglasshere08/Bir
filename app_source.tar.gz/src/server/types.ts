export interface DoctorProfile {
  id: string;
  name: string;
  title: string;
  specialties: string[];
  experienceYears: number;
  rating: number;
  reviewCount: number;
  avatarUrl: string;
  clinicName: string;
  clinicAddress: string;
  clinicOverview: string;
  clinicImages: Array<{
    src: string;
    title: string;
    caption: string;
  }>;
  timings: string;
  phone: string;
  email: string;
}

export interface TreatmentService {
  id: string;
  name: string;
  category: 'Endodontics' | 'Preventive' | 'Orthodontics' | 'Cardiology' | 'Cosmetic';
  durationMinutes: number;
  description: string;
  imageUrl: string;
  includes: string[];
}

export interface PatientReview {
  id: string;
  patientName: string;
  initials: string;
  rating: number;
  date: string;
  treatment: string;
  comment: string;
  verified: boolean;
  avatarColor?: string;
}

export interface PaymentTransaction {
  id: string;
  orderId: string;
  appointmentId?: string;
  amount: number;
  currency: string;
  method: 'upi' | 'card' | 'netbanking';
  upiApp?: string;
  upiId?: string;
  cardLast4?: string;
  cardBrand?: string;
  status: 'pending' | 'success' | 'failed';
  transactionRef: string;
  createdAt: string;
  receiptNumber: string;
}

export interface Appointment {
  id: string;
  appointmentNumber: string;
  patientName: string;
  patientPhone: string;
  patientEmail?: string;
  patientNotes?: string;
  serviceIds: string[];
  serviceNames: string[];
  services: Array<{
    id: string;
    name: string;
    price: number;
    duration: number;
  }>;
  baseAmount: number;
  discount: number;
  couponApplied?: string;
  gstAmount: number;
  totalAmount: number;
  currency: string;
  date: string; // YYYY-MM-DD
  time: string; // "04:15 PM"
  status: 'confirmed' | 'cancelled' | 'completed' | 'refunded';
  paymentId: string;
  paymentMethod: 'upi' | 'card' | 'netbanking';
  paymentDetails: {
    transactionRef: string;
    paidAt: string;
    receiptNumber: string;
    upiApp?: string;
    cardLast4?: string;
  };
  createdAt: string;
}

export interface DatabaseSchema {
  doctor: DoctorProfile;
  services: TreatmentService[];
  reviews: PatientReview[];
  appointments: Appointment[];
  transactions: PaymentTransaction[];
  blockedSlots: Array<{ date: string; time: string; reason: string }>;
}
