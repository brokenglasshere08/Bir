import { createClient, SupabaseClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL || 'https://eaasarhbhpymzffbkjtu.supabase.co';
const supabaseKey = process.env.SUPABASE_ANON_KEY || process.env.VITE_SUPABASE_ANON_KEY || 'sb_publishable_Qa7limzeHX2oDw88zjEUGw_6ky30zKz';

export const supabaseServer: SupabaseClient = createClient(supabaseUrl, supabaseKey);

export async function testSupabaseConnection(): Promise<{ ok: boolean; message: string; host: string }> {
  try {
    // Check connection against Supabase Auth gateway
    const authPromise = supabaseServer.auth.getSession();
    const timeoutPromise = new Promise((_, reject) =>
      setTimeout(() => reject(new Error('Supabase request timed out after 4s')), 4000)
    );

    const { error } = (await Promise.race([authPromise, timeoutPromise])) as any;

    if (!error) {
      return {
        ok: true,
        message: 'Connected to Supabase Project: eaasarhbhpymzffbkjtu',
        host: supabaseUrl
      };
    }

    return { ok: false, message: error.message || 'Supabase returned an error', host: supabaseUrl };
  } catch (err: any) {
    return { ok: false, message: err.message || 'Unknown network error', host: supabaseUrl };
  }
}
