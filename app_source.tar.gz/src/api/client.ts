import { DoctorProfile, TreatmentService, PatientReview, Appointment, PaymentTransaction } from '../server/types.js';

export interface PaymentOrderResponse {
  orderId: string;
  services: TreatmentService[];
  baseAmount: number;
  discount: number;
  gstAmount: number;
  totalAmount: number;
  currency: string;
  appliedCoupon?: string;
}

export interface AvailabilityResponse {
  date: string;
  unavailableSlots: Array<{
    time: string;
    reason: string;
    reopensAt?: string;
    durationMinutes?: number;
    isOccupiedNow?: boolean;
  }>;
}

export const api = {
  async getDoctor(): Promise<DoctorProfile> {
    const res = await fetch('/api/doctor');
    if (!res.ok) throw new Error('Failed to load doctor profile');
    return res.json();
  },

  async getServices(): Promise<TreatmentService[]> {
    const res = await fetch('/api/services');
    if (!res.ok) throw new Error('Failed to load clinic services');
    return res.json();
  },

  async getReviews(): Promise<PatientReview[]> {
    const res = await fetch('/api/reviews');
    if (!res.ok) throw new Error('Failed to load patient reviews');
    return res.json();
  },

  async submitReview(data: {
    patientName: string;
    rating: number;
    treatment: string;
    comment: string;
  }): Promise<PatientReview> {
    const res = await fetch('/api/reviews', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Failed to submit review' }));
      throw new Error(err.error || 'Failed to submit review');
    }
    return res.json();
  },

  async checkAvailability(date: string, duration?: number): Promise<AvailabilityResponse> {
    const url = duration
      ? `/api/appointments/availability?date=${encodeURIComponent(date)}&duration=${encodeURIComponent(duration)}`
      : `/api/appointments/availability?date=${encodeURIComponent(date)}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error('Failed to check slot availability');
    return res.json();
  },

  async createPaymentOrder(serviceIds: string[], couponCode?: string): Promise<PaymentOrderResponse> {
    const res = await fetch('/api/payments/create-order', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ serviceIds, couponCode })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Failed to create order' }));
      throw new Error(err.error || 'Failed to create payment order');
    }
    return res.json();
  },

  async processPayment(params: {
    orderId: string;
    amount: number;
    currency?: string;
    method: 'upi' | 'card' | 'netbanking';
    upiApp?: string;
    upiId?: string;
    cardLast4?: string;
    cardBrand?: string;
  }): Promise<{ success: boolean; transaction: PaymentTransaction }> {
    const res = await fetch('/api/payments/process', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Payment processing failed' }));
      throw new Error(err.error || 'Payment processing failed');
    }
    return res.json();
  },

  async bookAppointment(params: {
    patientName: string;
    patientPhone: string;
    patientEmail: string;
    patientNotes?: string;
    serviceIds: string[];
    date: string;
    time: string;
    paymentTransactionId: string;
    couponCode?: string;
  }): Promise<{ success: boolean; appointment: Appointment }> {
    const res = await fetch('/api/appointments/book', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Booking failed' }));
      throw new Error(err.error || 'Failed to book appointment');
    }
    return res.json();
  },

  async getAppointments(): Promise<Appointment[]> {
    const res = await fetch('/api/appointments');
    if (!res.ok) throw new Error('Failed to fetch appointments');
    return res.json();
  },

  async cancelAppointment(id: string, reason?: string): Promise<{ success: boolean; appointment: Appointment; message: string }> {
    const res = await fetch(`/api/appointments/${id}/cancel`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reason })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Cancellation failed' }));
      throw new Error(err.error || 'Failed to cancel appointment');
    }
    return res.json();
  },

  async reopenSlot(id: string): Promise<{ success: boolean; appointment: Appointment; message: string }> {
    const res = await fetch(`/api/appointments/${id}/reopen-slot`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Failed to reopen slot' }));
      throw new Error(err.error || 'Failed to reopen slot');
    }
    return res.json();
  }
};
