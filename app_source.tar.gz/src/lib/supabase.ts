import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://eaasarhbhpymzffbkjtu.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'sb_publishable_Qa7limzeHX2oDw88zjEUGw_6ky30zKz';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface SupabaseAppointmentRecord {
  id: string;
  booking_reference: string;
  patient_name: string;
  patient_phone: string;
  patient_email: string;
  patient_notes?: string;
  service_ids: string[];
  service_names: string[];
  date: string;
  time: string;
  total_amount: number;
  payment_status: 'PAID' | 'PENDING' | 'FAILED';
  payment_method?: 'upi' | 'card' | 'netbanking';
  created_at?: string;
}

export interface SupabasePaymentRecord {
  id: string;
  order_id: string;
  amount: number;
  currency: string;
  method: string;
  status: string;
  transaction_ref: string;
  upi_app?: string;
  card_last4?: string;
  card_brand?: string;
  bank_name?: string;
  created_at?: string;
}
