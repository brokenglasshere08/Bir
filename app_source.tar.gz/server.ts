import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { db } from './src/server/db.js';
import { supabaseServer, testSupabaseConnection } from './src/server/supabase.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const isProd = process.env.NODE_ENV === 'production';

app.use(express.json());

// API Endpoints

// Health check
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

// Get doctor profile and clinic information
app.get('/api/doctor', (_req: Request, res: Response) => {
  try {
    const doctor = db.getDoctor();
    res.json(doctor);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to fetch doctor profile' });
  }
});

// Get all medical and dental treatment services
app.get('/api/services', (_req: Request, res: Response) => {
  try {
    const services = db.getServices();
    res.json(services);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to fetch services' });
  }
});

// Get verified patient reviews
app.get('/api/reviews', (_req: Request, res: Response) => {
  try {
    const reviews = db.getReviews();
    res.json(reviews);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to fetch reviews' });
  }
});

// Submit a new patient review
app.post('/api/reviews', (req: Request, res: Response) => {
  try {
    const { patientName, rating, treatment, comment } = req.body;
    if (!patientName || !rating || !comment) {
      return res.status(400).json({ error: 'Patient name, rating, and review comment are required' });
    }

    const initials = patientName
      .trim()
      .split(' ')
      .map((part: string) => part[0])
      .join('')
      .toUpperCase()
      .slice(0, 2) || 'PT';

    const newReview = db.addReview({
      patientName: patientName.trim(),
      initials,
      rating: Number(rating),
      treatment: treatment?.trim() || 'General Consultation',
      comment: comment.trim()
    });

    res.status(201).json(newReview);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to save review' });
  }
});

// Check unavailable / booked slots for a given date and service duration
app.get('/api/appointments/availability', (req: Request, res: Response) => {
  try {
    const date = req.query.date as string;
    const durationParam = req.query.duration as string;
    const duration = durationParam ? parseInt(durationParam, 10) : 45;

    if (!date) {
      return res.status(400).json({ error: 'Date query parameter (YYYY-MM-DD) is required' });
    }

    const unavailable = db.getUnavailableSlots(date, isNaN(duration) ? 45 : duration);
    res.json({
      date,
      duration: isNaN(duration) ? 45 : duration,
      unavailableSlots: unavailable
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to check availability' });
  }
});

// Payment Gateway: Create Payment Order
app.post('/api/payments/create-order', (req: Request, res: Response) => {
  try {
    const { serviceIds, couponCode } = req.body;
    if (!serviceIds || !Array.isArray(serviceIds) || serviceIds.length === 0) {
      return res.status(400).json({ error: 'At least one service ID must be provided' });
    }

    const order = db.createPaymentOrder({
      serviceIds,
      couponCode
    });

    res.json(order);
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to create payment order' });
  }
});

// Payment Gateway: Process Payment Transaction
app.post('/api/payments/process', (req: Request, res: Response) => {
  try {
    const { orderId, amount, currency, method, upiApp, upiId, cardLast4, cardBrand } = req.body;

    if (!orderId || typeof amount !== 'number') {
      return res.status(400).json({ error: 'orderId and valid numerical amount are required' });
    }

    if (method !== 'upi' && method !== 'card' && method !== 'netbanking') {
      return res.status(400).json({ error: 'Supported payment methods are upi, card, netbanking' });
    }

    // Process payment transaction securely in DB
    const transaction = db.processPayment({
      orderId,
      amount,
      currency: currency || 'INR',
      method,
      upiApp,
      upiId,
      cardLast4,
      cardBrand
    });

    // Asynchronously replicate payment record to Supabase
    Promise.resolve(
      supabaseServer
        .from('payments')
        .insert({
          order_id: transaction.orderId,
          amount: transaction.amount,
          currency: transaction.currency,
          method: transaction.method,
          status: transaction.status,
          transaction_ref: transaction.transactionRef,
          upi_app: transaction.upiApp || null,
          upi_id: transaction.upiId || null,
          card_last4: transaction.cardLast4 || null,
          card_brand: transaction.cardBrand || null,
          bank_name: req.body.bankName || null
        })
    )
      .then(({ error }: any) => {
        if (error && error.code !== 'PGRST205') {
          console.warn('[Supabase payments sync note]:', error.message);
        }
      })
      .catch((e: any) => console.warn('[Supabase payments sync caught]:', e.message));

    res.json({
      success: true,
      transaction
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Payment processing error' });
  }
});

// Book confirmed appointment
app.post('/api/appointments/book', (req: Request, res: Response) => {
  try {
    const {
      patientName,
      patientPhone,
      patientEmail,
      patientNotes,
      serviceIds,
      date,
      time,
      paymentTransactionId,
      couponCode
    } = req.body;

    if (!patientName || !patientPhone) {
      return res.status(400).json({ error: 'Patient name and phone number are required' });
    }

    if (!date || !time) {
      return res.status(400).json({ error: 'Appointment date and time are required' });
    }

    if (!serviceIds || !Array.isArray(serviceIds) || serviceIds.length === 0) {
      return res.status(400).json({ error: 'Selected service IDs are required' });
    }

    if (!paymentTransactionId) {
      return res.status(400).json({ error: 'Payment transaction reference is required for confirmation' });
    }

    const appointment = db.bookAppointment({
      patientName,
      patientPhone,
      patientEmail,
      patientNotes,
      serviceIds,
      date,
      time,
      paymentTransactionId,
      couponCode
    });

    // Asynchronously replicate appointment record to Supabase
    Promise.resolve(
      supabaseServer
        .from('appointments')
        .insert({
          booking_reference: appointment.appointmentNumber,
          patient_name: appointment.patientName,
          patient_phone: appointment.patientPhone,
          patient_email: appointment.patientEmail || '',
          patient_notes: appointment.patientNotes || '',
          service_ids: appointment.serviceIds,
          service_names: appointment.serviceNames,
          date: appointment.date,
          time: appointment.time,
          total_amount: appointment.totalAmount,
          payment_status: 'PAID',
          payment_method: appointment.paymentMethod,
          transaction_id: appointment.paymentDetails?.transactionRef || appointment.paymentId,
          status: appointment.status
        })
    )
      .then(({ error }: any) => {
        if (error && error.code !== 'PGRST205') {
          console.warn('[Supabase appointments sync note]:', error.message);
        }
      })
      .catch((e: any) => console.warn('[Supabase appointments sync caught]:', e.message));

    res.status(201).json({
      success: true,
      appointment
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to book appointment' });
  }
});

// Check Supabase connection status
app.get('/api/supabase/status', async (_req: Request, res: Response) => {
  try {
    const status = await testSupabaseConnection();
    res.json(status);
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// List all appointments (for user history & clinic schedule)
app.get('/api/appointments', (_req: Request, res: Response) => {
  try {
    const appointments = db.getAppointments();
    res.json(appointments);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to fetch appointments' });
  }
});

// Get single appointment
app.get('/api/appointments/:id', (req: Request, res: Response) => {
  try {
    const appointment = db.getAppointmentById(req.params.id);
    if (!appointment) {
      return res.status(404).json({ error: 'Appointment not found' });
    }
    res.json(appointment);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to fetch appointment' });
  }
});

// Cancel appointment
app.post('/api/appointments/:id/cancel', (req: Request, res: Response) => {
  try {
    const { reason } = req.body;
    const cancelled = db.cancelAppointment(req.params.id, reason);
    res.json({
      success: true,
      appointment: cancelled,
      message: 'Appointment successfully cancelled. Slot is now available again.'
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to cancel appointment' });
  }
});

// Reopen slot / Complete service immediately
app.post('/api/appointments/:id/reopen-slot', (req: Request, res: Response) => {
  try {
    const reopened = db.reopenSlot(req.params.id);
    res.json({
      success: true,
      appointment: reopened,
      message: 'Service marked complete and time slot has been reopened.'
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to reopen slot' });
  }
});

// Periodic background task: automatically update completed appointments and free slots
setInterval(() => {
  try {
    db.updateCompletedAppointments();
  } catch (e) {
    // silent
  }
}, 15000);

// Static / Dev Server Integration
async function startServer() {
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Healthcare Applet server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
